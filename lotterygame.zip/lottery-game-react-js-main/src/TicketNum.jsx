import "./TicketNum.css"

export default function TicketNum({num}) {
    return (
        <span className="ticketNum">{num}</span>
    )
}